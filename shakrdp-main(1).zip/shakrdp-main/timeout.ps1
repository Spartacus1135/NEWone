$i = 360
do {
    Write-Host $i
    Sleep 360
    $i--
} while ($i -gt 0)
